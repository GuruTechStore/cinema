


<?php $__env->startSection('title', $dulceria->nombre); ?>
<?php $__env->startSection('page-title', 'Producto: ' . $dulceria->nombre); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dulceria.index')); ?>">Dulcería</a></li>
<li class="breadcrumb-item active"><?php echo e($dulceria->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Información del Producto -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-candy-cane me-2"></i>Información del Producto
                </h5>
                <div>
                    <span class="badge <?php echo e($dulceria->activo ? 'bg-success' : 'bg-danger'); ?> fs-6">
                        <?php echo e($dulceria->activo ? 'Activo' : 'Inactivo'); ?>

                    </span>
                    <?php if($dulceria->es_combo): ?>
                        <span class="badge bg-warning fs-6 ms-2">Combo</span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card-body">
                <div class="row">
                    <!-- Imagen -->
                    <div class="col-md-4">
                        <?php if($dulceria->imagen): ?>
                            <img src="<?php echo e(asset('storage/' . $dulceria->imagen)); ?>" 
                                 alt="<?php echo e($dulceria->nombre); ?>" 
                                 class="img-fluid rounded shadow-sm">
                        <?php else: ?>
                            <div class="bg-light rounded d-flex align-items-center justify-content-center shadow-sm" 
                                 style="height: 200px;">
                                <div class="text-center text-muted">
                                    <i class="fas fa-image fa-3x mb-2"></i>
                                    <p>Sin imagen</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Detalles -->
                    <div class="col-md-8">
                        <table class="table table-borderless">
                            <tr>
                                <th width="30%">ID:</th>
                                <td><span class="badge bg-secondary">#<?php echo e($dulceria->id); ?></span></td>
                            </tr>
                            <tr>
                                <th>Nombre:</th>
                                <td><strong class="fs-5"><?php echo e($dulceria->nombre); ?></strong></td>
                            </tr>
                            <tr>
                                <th>Categoría:</th>
                                <td><span class="badge bg-info"><?php echo e($dulceria->categoria->nombre); ?></span></td>
                            </tr>
                            <tr>
                                <th>Precio:</th>
                                <td><strong class="text-success fs-4">S/ <?php echo e(number_format($dulceria->precio, 2)); ?></strong></td>
                            </tr>
                            <tr>
                                <th>Tipo:</th>
                                <td>
                                    <?php if($dulceria->es_combo): ?>
                                        <span class="badge bg-warning">
                                            <i class="fas fa-boxes me-1"></i>Combo
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-primary">
                                            <i class="fas fa-cookie-bite me-1"></i>Producto Individual
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Estado:</th>
                                <td>
                                    <?php if($dulceria->activo): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check me-1"></i>Activo
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-times me-1"></i>Inactivo
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>

                        <?php if($dulceria->descripcion): ?>
                        <div class="mt-3">
                            <h6>Descripción:</h6>
                            <p class="text-muted"><?php echo e($dulceria->descripcion); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Estadísticas de Ventas -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2"></i>Estadísticas de Ventas
                </h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-md-3">
                        <div class="border rounded p-3">
                            <h4 class="text-primary"><?php echo e($totalVendido ?? 0); ?></h4>
                            <p class="mb-0">Total Vendido</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded p-3">
                            <h4 class="text-success">S/ <?php echo e(number_format($ingresosTotales ?? 0, 2)); ?></h4>
                            <p class="mb-0">Ingresos Totales</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded p-3">
                            <h4 class="text-warning"><?php echo e($ventasEsteMes ?? 0); ?></h4>
                            <p class="mb-0">Ventas Este Mes</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded p-3">
                            <h4 class="text-info"><?php echo e($ventasHoy ?? 0); ?></h4>
                            <p class="mb-0">Ventas Hoy</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Historial de Pedidos -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-history me-2"></i>Últimos Pedidos
                </h5>
            </div>
            <div class="card-body">
                <?php if($ultimosPedidos && $ultimosPedidos->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Cliente</th>
                                    <th>Cantidad</th>
                                    <th>Subtotal</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ultimosPedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->pedido->created_at->format('d/m/Y H:i')); ?></td>
                                    <td><?php echo e($item->pedido->user->name); ?></td>
                                    <td><?php echo e($item->cantidad); ?></td>
                                    <td>S/ <?php echo e(number_format($item->subtotal, 2)); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($item->pedido->estado == 'confirmado' ? 'success' : 'warning'); ?>">
                                            <?php echo e(ucfirst($item->pedido->estado)); ?>

                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-shopping-bag fa-3x mb-3"></i>
                        <p>No hay pedidos registrados para este producto</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Panel de Acciones -->
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-cogs me-2"></i>Acciones
                </h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('admin.dulceria.edit', $dulceria)); ?>" class="btn btn-primary">
                        <i class="fas fa-edit me-2"></i>Editar Producto
                    </a>
                    
                    <form method="POST" action="<?php echo e(route('admin.dulceria.toggle-status', $dulceria)); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-<?php echo e($dulceria->activo ? 'warning' : 'success'); ?> w-100"
                                onclick="return confirm('¿Cambiar estado del producto?')">
                            <i class="fas fa-<?php echo e($dulceria->activo ? 'pause' : 'play'); ?> me-2"></i>
                            <?php echo e($dulceria->activo ? 'Desactivar' : 'Activar'); ?>

                        </button>
                    </form>
                    
                    <a href="<?php echo e(route('admin.dulceria.create')); ?>" class="btn btn-outline-info">
                        <i class="fas fa-plus me-2"></i>Crear Nuevo Producto
                    </a>
                    
                    <hr>
                    
                    <form method="POST" action="<?php echo e(route('admin.dulceria.destroy', $dulceria)); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-danger w-100"
                                onclick="return confirm('¿Estás seguro de eliminar este producto? Esta acción no se puede deshacer.')">
                            <i class="fas fa-trash me-2"></i>Eliminar Producto
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Información Técnica -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-info-circle me-2"></i>Información Técnica
                </h5>
            </div>
            <div class="card-body">
                <table class="table table-sm table-borderless">
                    <tr>
                        <th>Creado:</th>
                        <td><?php echo e($dulceria->created_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                    <tr>
                        <th>Actualizado:</th>
                        <td><?php echo e($dulceria->updated_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                    <tr>
                        <th>ID Categoría:</th>
                        <td>#<?php echo e($dulceria->categoria_dulceria_id); ?></td>
                    </tr>
                    <?php if($dulceria->imagen): ?>
                    <tr>
                        <th>Archivo Imagen:</th>
                        <td>
                            <small class="text-muted"><?php echo e(basename($dulceria->imagen)); ?></small>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>

        <!-- Vista Previa Pública -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-eye me-2"></i>Vista Previa
                </h5>
            </div>
            <div class="card-body">
                <p class="text-muted mb-3">Así se ve en la dulcería pública:</p>
                
                <!-- Simulación del card público -->
                <div class="card border">
                    <div class="position-relative">
                        <?php if($dulceria->imagen): ?>
                            <img src="<?php echo e(asset('storage/' . $dulceria->imagen)); ?>" 
                                 class="card-img-top" 
                                 style="height: 150px; object-fit: cover;" 
                                 alt="<?php echo e($dulceria->nombre); ?>">
                        <?php else: ?>
                            <div class="bg-light d-flex align-items-center justify-content-center" 
                                 style="height: 150px;">
                                <i class="fas fa-candy-cane fa-2x text-muted"></i>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($dulceria->es_combo): ?>
                            <span class="position-absolute top-0 end-0 badge bg-warning m-2">Combo</span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-body p-3">
                        <h6 class="card-title"><?php echo e($dulceria->nombre); ?></h6>
                        <?php if($dulceria->descripcion): ?>
                            <p class="card-text small text-muted">
                                <?php echo e(Str::limit($dulceria->descripcion, 60)); ?>

                            </p>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="h6 text-success mb-0">S/ <?php echo e(number_format($dulceria->precio, 2)); ?></span>
                            <button class="btn btn-sm btn-outline-primary" disabled>
                                <i class="fas fa-cart-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <?php if(!$dulceria->activo): ?>
                    <div class="alert alert-warning mt-2 mb-0">
                        <small><i class="fas fa-exclamation-triangle me-1"></i>
                        Este producto no aparece públicamente porque está inactivo</small>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Confirmaciones para acciones
    $('form[action*="destroy"]').submit(function(e) {
        return confirm('¿Estás seguro de eliminar este producto?\n\nEsta acción no se puede deshacer.\nTodos los pedidos relacionados mantendrán la información del producto.');
    });

    $('form[action*="toggle-status"]').submit(function(e) {
        const isActive = <?php echo e($dulceria->activo ? 'true' : 'false'); ?>;
        const action = isActive ? 'desactivar' : 'activar';
        return confirm(`¿Estás seguro de ${action} este producto?`);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/admin/dulceria/show.blade.php ENDPATH**/ ?>