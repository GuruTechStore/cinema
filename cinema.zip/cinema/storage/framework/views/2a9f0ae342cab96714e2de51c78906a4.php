


<?php $__env->startSection('title', 'Mis Reservas - Butaca del Salchicon'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">
                    <i class="fas fa-ticket-alt me-2 text-primary"></i>Mis Reservas
                </h2>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-primary">
                    <i class="fas fa-home me-2"></i>Volver al Inicio
                </a>
            </div>

            <?php if($reservas->count() > 0): ?>
                <div class="row">
                    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0 fw-bold"><?php echo e($reserva->funcion->pelicula->titulo); ?></h6>
                                <small><?php echo e($reserva->created_at->format('d M Y - H:i')); ?></small>
                            </div>
                            
                            <div class="card-body">
                                <div class="mb-2">
                                    <strong>Cine:</strong> <?php echo e($reserva->funcion->sala->cine->nombre); ?>

                                </div>
                                <div class="mb-2">
                                    <strong>Sala:</strong> <?php echo e($reserva->funcion->sala->nombre); ?>

                                </div>
                                <div class="mb-2">
                                    <strong>Fecha:</strong> <?php echo e($reserva->funcion->fecha_funcion->format('d M Y')); ?>

                                </div>
                                <div class="mb-2">
                                    <strong>Hora:</strong> <?php echo e($reserva->funcion->hora_funcion->format('H:i')); ?>

                                </div>
                                <div class="mb-2">
                                    <strong>Asientos:</strong> <?php echo e($reserva->getAsientosFormateados()); ?>

                                </div>
                                <div class="mb-2">
                                    <strong>Total:</strong> <span class="fw-bold text-success"><?php echo e(formatPrice($reserva->monto_total)); ?></span>
                                </div>
                                
                                <!-- Estado de la reserva -->
                                <div class="mb-3">
                                    <?php if($reserva->estado == 'confirmada'): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check me-1"></i>Confirmada
                                        </span>
                                    <?php elseif($reserva->estado == 'pendiente'): ?>
                                        <span class="badge bg-warning">
                                            <i class="fas fa-clock me-1"></i>Pendiente
                                        </span>
                                    <?php elseif($reserva->estado == 'cancelada'): ?>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-times me-1"></i>Cancelada
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <!-- Código de reserva destacado -->
                                <div class="bg-light p-2 rounded text-center mb-3">
                                    <small class="text-muted">Código de Reserva</small>
                                    <div class="fw-bold fs-5"><?php echo e($reserva->codigo_reserva); ?></div>
                                </div>
                            </div>
                            
                            <div class="card-footer">
                                <div class="d-grid gap-2">
                                    <a href="<?php echo e(route('reservas.boleta', $reserva)); ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-receipt me-1"></i>Ver Boleta
                                    </a>
                                    <?php if($reserva->estado == 'confirmada' && $reserva->funcion->fecha_funcion->isFuture()): ?>
                                        <small class="text-muted text-center">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Presenta tu código en taquilla
                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Paginación -->
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($reservas->links()); ?>

                </div>

            <?php else: ?>
                <div class="text-center py-5">
                    <div class="mb-4">
                        <i class="fas fa-ticket-alt display-1 text-muted"></i>
                    </div>
                    <h4 class="text-muted mb-3">No tienes reservas aún</h4>
                    <p class="text-muted mb-4">¡Explora nuestra cartelera y reserva tu película favorita!</p>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg">
                        <i class="fas fa-film me-2"></i>Ver Cartelera
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/reservas/mis-reservas.blade.php ENDPATH**/ ?>