<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Debug - Selección de Asientos</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .debug-box { background: #f8f9fa; border: 1px solid #dee2e6; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .error { background: #f8d7da; border-color: #f5c6cb; color: #721c24; }
        .success { background: #d4edda; border-color: #c3e6cb; color: #155724; }
        .warning { background: #fff3cd; border-color: #ffeaa7; color: #856404; }
        button { padding: 10px 20px; margin: 5px; cursor: pointer; }
        .seat { width: 30px; height: 30px; margin: 2px; display: inline-block; text-align: center; line-height: 30px; cursor: pointer; }
        .available { background: #28a745; color: white; }
        .selected { background: #007bff; color: white; }
        .occupied { background: #6c757d; color: white; cursor: not-allowed; }
    </style>
</head>
<body>
    <h1>🔧 Debug de Selección de Asientos</h1>
    
    <div class="debug-box">
        <h3>1. Prueba de Selección de Asientos</h3>
        <p>Haz clic en los asientos disponibles (verdes) para simular la selección:</p>
        
        <div id="asientos-test">
            <div class="seat available" data-seat="A1">A1</div>
            <div class="seat available" data-seat="A2">A2</div>
            <div class="seat available" data-seat="A3">A3</div>
            <div class="seat occupied" data-seat="A4">A4</div>
            <div class="seat available" data-seat="A5">A5</div>
        </div>
        
        <div id="debug-output" class="debug-box warning">
            <strong>Asientos seleccionados:</strong> <span id="asientos-list">Ninguno</span><br>
            <strong>Cantidad:</strong> <span id="cantidad">0</span><br>
            <strong>JSON:</strong> <span id="json-output">[]</span>
        </div>
    </div>

    <div class="debug-box">
        <h3>2. Simulación de Formulario</h3>
        <form id="test-form">
            <input type="hidden" name="asientos" id="input-asientos">
            <button type="submit" id="btn-continuar" disabled>DETALLES (Test)</button>
        </form>
        
        <div id="form-debug" class="debug-box">
            <strong>Estado del botón:</strong> <span id="btn-state">Deshabilitado</span><br>
            <strong>Valor del input hidden:</strong> <span id="input-value">Vacío</span>
        </div>
    </div>

    <div class="debug-box">
        <h3>3. Verificaciones Técnicas</h3>
        <button onclick="checkJQuery()">Verificar jQuery</button>
        <button onclick="checkConsoleErrors()">Ver Errores de Consola</button>
        <button onclick="checkFormSubmission()">Probar Envío</button>
        
        <div id="tech-results" class="debug-box"></div>
    </div>

    <div class="debug-box">
        <h3>4. Pasos para Diagnóstico en tu Aplicación</h3>
        <ol>
            <li><strong>Presiona F12</strong> en tu navegador</li>
            <li><strong>Ve a la pestaña Console</strong></li>
            <li><strong>Selecciona asientos</strong> en tu aplicación</li>
            <li><strong>Busca errores en rojo</strong> en la consola</li>
            <li><strong>Ve a la pestaña Network</strong></li>
            <li><strong>Haz clic en DETALLES</strong></li>
            <li><strong>Verifica si hay alguna petición HTTP</strong></li>
        </ol>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            let asientosSeleccionados = [];
            
            // Simular la lógica de selección de asientos
            $('.seat.available').click(function() {
                const asientoId = $(this).data('seat');
                
                if ($(this).hasClass('selected')) {
                    // Deseleccionar
                    $(this).removeClass('selected').addClass('available');
                    asientosSeleccionados = asientosSeleccionados.filter(a => a !== asientoId);
                } else {
                    // Seleccionar
                    $(this).removeClass('available').addClass('selected');
                    asientosSeleccionados.push(asientoId);
                }
                
                actualizarDebug();
            });
            
            function actualizarDebug() {
                const cantidad = asientosSeleccionados.length;
                
                $('#asientos-list').text(asientosSeleccionados.join(', ') || 'Ninguno');
                $('#cantidad').text(cantidad);
                $('#json-output').text(JSON.stringify(asientosSeleccionados));
                
                if (cantidad > 0) {
                    $('#btn-continuar').prop('disabled', false);
                    $('#input-asientos').val(JSON.stringify(asientosSeleccionados));
                    $('#btn-state').text('Habilitado').css('color', 'green');
                } else {
                    $('#btn-continuar').prop('disabled', true);
                    $('#input-asientos').val('');
                    $('#btn-state').text('Deshabilitado').css('color', 'red');
                }
                
                $('#input-value').text($('#input-asientos').val() || 'Vacío');
            }
            
            // Manejar envío del formulario de prueba
            $('#test-form').submit(function(e) {
                e.preventDefault();
                
                const asientos = $('#input-asientos').val();
                
                if (!asientos) {
                    alert('❌ Error: No hay asientos seleccionados');
                    return;
                }
                
                try {
                    const asientosArray = JSON.parse(asientos);
                    alert(`✅ Formulario funcionando! Asientos: ${asientosArray.join(', ')}`);
                } catch (error) {
                    alert(`❌ Error en JSON: ${error.message}`);
                }
            });
        });
        
        function checkJQuery() {
            const result = document.getElementById('tech-results');
            
            if (typeof $ !== 'undefined') {
                result.innerHTML = '<div class="success">✅ jQuery está funcionando correctamente</div>';
            } else {
                result.innerHTML = '<div class="error">❌ jQuery NO está cargado</div>';
            }
        }
        
        function checkConsoleErrors() {
            const result = document.getElementById('tech-results');
            result.innerHTML = '<div class="warning">📋 Abre la consola (F12 → Console) y busca errores en rojo cuando selecciones asientos en tu aplicación</div>';
        }
        
        function checkFormSubmission() {
            const result = document.getElementById('tech-results');
            
            // Simular datos de prueba
            $('#input-asientos').val('["A1", "A2"]');
            $('#btn-continuar').prop('disabled', false);
            
            result.innerHTML = '<div class="success">✅ Datos de prueba añadidos. Haz clic en "DETALLES (Test)" para probar</div>';
        }
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/debug/asientos.blade.php ENDPATH**/ ?>