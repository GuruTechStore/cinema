


<?php $__env->startSection('title', 'Películas - Butaca del Salchicon'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <section class="py-5 bg-primary text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold mb-3">Películas</h1>
                    <p class="lead">Descubre los últimos estrenos y próximas películas</p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="fas fa-film display-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Filtros -->
    <section class="py-4 bg-light">
        <div class="container">
            <div class="card shadow-sm">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Buscar película</label>
                            <input type="text" class="form-control" name="buscar" 
                                   placeholder="Título de la película..." value="<?php echo e(request('buscar')); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold">Género</label>
                            <select class="form-select" name="genero">
                                <option value="">Todos</option>
                                <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($genero); ?>" <?php echo e(request('genero') == $genero ? 'selected' : ''); ?>>
                                        <?php echo e($genero); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold">Ciudad</label>
                            <select class="form-select" name="ciudad_id">
                                <option value="">Todas</option>
                                <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ciudad->id); ?>" <?php echo e(request('ciudad_id') == $ciudad->id ? 'selected' : ''); ?>>
                                        <?php echo e($ciudad->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold">Fecha</label>
                            <input type="date" class="form-control" name="fecha" value="<?php echo e(request('fecha')); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold">Ordenar</label>
                            <select class="form-select" name="orden">
                                <option value="fecha_estreno" <?php echo e(request('orden') == 'fecha_estreno' ? 'selected' : ''); ?>>Fecha estreno</option>
                                <option value="titulo" <?php echo e(request('orden') == 'titulo' ? 'selected' : ''); ?>>Título A-Z</option>
                                <option value="popularidad" <?php echo e(request('orden') == 'popularidad' ? 'selected' : ''); ?>>Popularidad</option>
                            </select>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Películas Grid -->
    <section class="py-5">
        <div class="container">
            <?php if($peliculas->count() > 0): ?>
                <div class="row g-4">
                    <?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('components.movie-card', ['pelicula' => $pelicula], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Paginación -->
                <?php if($peliculas->hasPages()): ?>
                    <div class="d-flex justify-content-center mt-5">
                        <?php echo e($peliculas->appends(request()->query())->links()); ?>

                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-film display-1 text-muted mb-3"></i>
                    <h3 class="text-muted">No se encontraron películas</h3>
                    <p class="text-muted">Intenta ajustar los filtros de búsqueda</p>
                    <a href="<?php echo e(route('peliculas')); ?>" class="btn btn-primary">
                        <i class="fas fa-refresh me-2"></i>Ver todas las películas
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/home/peliculas.blade.php ENDPATH**/ ?>