


<?php $__env->startSection('title', 'Gestión de Reservas'); ?>
<?php $__env->startSection('page-title', 'Reservas de Boletos'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active">Reservas</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Estadísticas rápidas -->
<div class="row g-4 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card">
            <div class="card-body text-center">
                <h3 class="text-primary"><?php echo e(number_format($totalReservas)); ?></h3>
                <p class="mb-0">Total Reservas</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card success">
            <div class="card-body text-center">
                <h3 class="text-success"><?php echo e(number_format($reservasHoy)); ?></h3>
                <p class="mb-0">Reservas Hoy</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card warning">
            <div class="card-body text-center">
                <h3 class="text-warning">S/ <?php echo e(number_format($ingresosTotales, 2)); ?></h3>
                <p class="mb-0">Ingresos Totales</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card info">
            <div class="card-body text-center">
                <h3 class="text-info">S/ <?php echo e(number_format($ingresosHoy, 2)); ?></h3>
                <p class="mb-0">Ingresos Hoy</p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-ticket-alt me-2"></i>Gestión de Reservas
                </h5>
            </div>
            
            <div class="card-body">
                <!-- Filtros -->
                <form method="GET" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-2">
                            <select name="estado" class="form-select">
                                <option value="">Todos los estados</option>
                                <option value="confirmada" <?php echo e(request('estado') == 'confirmada' ? 'selected' : ''); ?>>Confirmada</option>
                                <option value="pendiente" <?php echo e(request('estado') == 'pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                                <option value="cancelada" <?php echo e(request('estado') == 'cancelada' ? 'selected' : ''); ?>>Cancelada</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <input type="date" name="fecha_desde" class="form-control" 
                                   value="<?php echo e(request('fecha_desde')); ?>" placeholder="Fecha desde">
                        </div>
                        <div class="col-md-2">
                            <input type="date" name="fecha_hasta" class="form-control" 
                                   value="<?php echo e(request('fecha_hasta')); ?>" placeholder="Fecha hasta">
                        </div>
                        <div class="col-md-2">
                            <input type="text" name="pelicula" class="form-control" 
                                   value="<?php echo e(request('pelicula')); ?>" placeholder="Película">
                        </div>
                        <div class="col-md-2">
                            <input type="text" name="usuario" class="form-control" 
                                   value="<?php echo e(request('usuario')); ?>" placeholder="Usuario">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-1"></i>Filtrar
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Tabla de reservas -->
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Película</th>
                                <th>Función</th>
                                <th>Asientos</th>
                                <th>Total</th>
                                <th>Estado</th>
                                <th>Fecha</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary">#<?php echo e($reserva->id); ?></span>
                                    <br>
                                    <small class="text-muted"><?php echo e($reserva->codigo_reserva); ?></small>
                                </td>
                                
                                <td>
                                    <strong><?php echo e($reserva->user->name); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($reserva->user->email); ?></small>
                                </td>
                                
                                <td>
                                    <strong><?php echo e($reserva->funcion->pelicula->titulo); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <?php echo e($reserva->funcion->sala->cine->nombre); ?>

                                    </small>
                                </td>
                                
                                <td>
                                    <strong><?php echo e($reserva->funcion->fecha_funcion->format('d/m/Y')); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <?php echo e($reserva->funcion->hora_funcion->format('H:i')); ?> - 
                                        <?php echo e($reserva->funcion->sala->nombre); ?>

                                    </small>
                                </td>
                                
                                <td>
                                    <span class="badge bg-info"><?php echo e($reserva->total_boletos); ?> boletos</span>
                                    <br>
                                    <small class="text-muted"><?php echo e($reserva->getAsientosFormateados()); ?></small>
                                </td>
                                
                                <td>
                                    <strong class="text-success">S/ <?php echo e(number_format($reserva->monto_total, 2)); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e(ucfirst($reserva->metodo_pago)); ?></small>
                                </td>
                                
                                <td>
                                    <?php if($reserva->estado == 'confirmada'): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check me-1"></i>Confirmada
                                        </span>
                                    <?php elseif($reserva->estado == 'pendiente'): ?>
                                        <span class="badge bg-warning">
                                            <i class="fas fa-clock me-1"></i>Pendiente
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-times me-1"></i>Cancelada
                                        </span>
                                    <?php endif; ?>
                                </td>
                                
                                <td>
                                    <strong><?php echo e($reserva->created_at->format('d/m/Y')); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($reserva->created_at->format('H:i')); ?></small>
                                </td>
                                
                                <td>
                                    <div class="btn-group-vertical" role="group">
                                        <a href="<?php echo e(route('reservas.boleta', $reserva)); ?>" 
                                           class="btn btn-sm btn-outline-primary" 
                                           title="Ver boleta" target="_blank">
                                            <i class="fas fa-receipt"></i>
                                        </a>
                                        
                                        <?php if($reserva->estado == 'pendiente'): ?>
                                        <button class="btn btn-sm btn-outline-success" 
                                                onclick="cambiarEstado(<?php echo e($reserva->id); ?>, 'confirmada')"
                                                title="Confirmar">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        
                                        <button class="btn btn-sm btn-outline-danger" 
                                                onclick="cambiarEstado(<?php echo e($reserva->id); ?>, 'cancelada')"
                                                title="Cancelar">
                                            <i class="fas fa-times"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-5">
                                    <div class="text-muted">
                                        <i class="fas fa-ticket-alt fa-3x mb-3"></i>
                                        <h5>No hay reservas</h5>
                                        <p>No se encontraron reservas con los filtros aplicados</p>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación -->
                <?php if($reservas->hasPages()): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($reservas->appends(request()->query())->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function cambiarEstado(reservaId, nuevoEstado) {
    const mensaje = nuevoEstado === 'confirmada' ? 
        '¿Confirmar esta reserva?' : 
        '¿Cancelar esta reserva?';
    
    if (confirm(mensaje)) {
        // Aquí podrías hacer una llamada AJAX para cambiar el estado
        fetch(`/admin/reservas/${reservaId}/estado`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                estado: nuevoEstado
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error al cambiar el estado');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cambiar el estado');
        });
    }
}

// Exportar a Excel (opcional)
function exportarExcel() {
    const params = new URLSearchParams(window.location.search);
    params.append('export', 'excel');
    window.location.href = `/admin/reservas?${params.toString()}`;
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/admin/reservas.blade.php ENDPATH**/ ?>