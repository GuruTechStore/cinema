


<?php $__env->startSection('title', 'Editar Película'); ?>
<?php $__env->startSection('page-title', 'Editar Película'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.peliculas.index')); ?>">Películas</a></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.peliculas.show', $pelicula)); ?>"><?php echo e($pelicula->titulo); ?></a></li>
<li class="breadcrumb-item active">Editar</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-edit me-2"></i>Editar: <?php echo e($pelicula->titulo); ?>

                </h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.peliculas.update', $pelicula)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="row g-3">
                        <!-- Título -->
                        <div class="col-md-8">
                            <label class="form-label fw-bold">Título *</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="titulo" value="<?php echo e(old('titulo', $pelicula->titulo)); ?>" required>
                            <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Clasificación -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Clasificación *</label>
                            <select class="form-select <?php $__errorArgs = ['clasificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="clasificacion" required>
                                <option value="">Seleccionar</option>
                                <option value="G" <?php echo e(old('clasificacion', $pelicula->clasificacion) == 'G' ? 'selected' : ''); ?>>G - General</option>
                                <option value="PG" <?php echo e(old('clasificacion', $pelicula->clasificacion) == 'PG' ? 'selected' : ''); ?>>PG - Parental Guidance</option>
                                <option value="PG-13" <?php echo e(old('clasificacion', $pelicula->clasificacion) == 'PG-13' ? 'selected' : ''); ?>>PG-13</option>
                                <option value="R" <?php echo e(old('clasificacion', $pelicula->clasificacion) == 'R' ? 'selected' : ''); ?>>R - Restricted</option>
                                <option value="NC-17" <?php echo e(old('clasificacion', $pelicula->clasificacion) == 'NC-17' ? 'selected' : ''); ?>>NC-17</option>
                            </select>
                            <?php $__errorArgs = ['clasificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Director -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Director *</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="director" value="<?php echo e(old('director', $pelicula->director)); ?>" required>
                            <?php $__errorArgs = ['director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Género -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Género *</label>
                            <select class="form-select <?php $__errorArgs = ['genero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="genero" required>
                                <option value="">Seleccionar</option>
                                <option value="Acción" <?php echo e(old('genero', $pelicula->genero) == 'Acción' ? 'selected' : ''); ?>>Acción</option>
                                <option value="Aventura" <?php echo e(old('genero', $pelicula->genero) == 'Aventura' ? 'selected' : ''); ?>>Aventura</option>
                                <option value="Comedia" <?php echo e(old('genero', $pelicula->genero) == 'Comedia' ? 'selected' : ''); ?>>Comedia</option>
                                <option value="Drama" <?php echo e(old('genero', $pelicula->genero) == 'Drama' ? 'selected' : ''); ?>>Drama</option>
                                <option value="Terror" <?php echo e(old('genero', $pelicula->genero) == 'Terror' ? 'selected' : ''); ?>>Terror</option>
                                <option value="Ciencia Ficción" <?php echo e(old('genero', $pelicula->genero) == 'Ciencia Ficción' ? 'selected' : ''); ?>>Ciencia Ficción</option>
                                <option value="Animación" <?php echo e(old('genero', $pelicula->genero) == 'Animación' ? 'selected' : ''); ?>>Animación</option>
                                <option value="Documental" <?php echo e(old('genero', $pelicula->genero) == 'Documental' ? 'selected' : ''); ?>>Documental</option>
                                <option value="Romance" <?php echo e(old('genero', $pelicula->genero) == 'Romance' ? 'selected' : ''); ?>>Romance</option>
                                <option value="Thriller" <?php echo e(old('genero', $pelicula->genero) == 'Thriller' ? 'selected' : ''); ?>>Thriller</option>
                            </select>
                            <?php $__errorArgs = ['genero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Duración -->
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Duración (min) *</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['duracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="duracion" value="<?php echo e(old('duracion', $pelicula->duracion)); ?>" min="1" required>
                            <?php $__errorArgs = ['duracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Idioma -->
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Idioma</label>
                            <select class="form-select <?php $__errorArgs = ['idioma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="idioma">
                                <option value="">Seleccionar</option>
                                <option value="Español" <?php echo e(old('idioma', $pelicula->idioma) == 'Español' ? 'selected' : ''); ?>>Español</option>
                                <option value="Inglés" <?php echo e(old('idioma', $pelicula->idioma) == 'Inglés' ? 'selected' : ''); ?>>Inglés</option>
                                <option value="Subtitulada" <?php echo e(old('idioma', $pelicula->idioma) == 'Subtitulada' ? 'selected' : ''); ?>>Subtitulada</option>
                                <option value="Doblada" <?php echo e(old('idioma', $pelicula->idioma) == 'Doblada' ? 'selected' : ''); ?>>Doblada</option>
                            </select>
                            <?php $__errorArgs = ['idioma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Fecha de Estreno -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Fecha de Estreno *</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['fecha_estreno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="fecha_estreno" value="<?php echo e(old('fecha_estreno', $pelicula->fecha_estreno->format('Y-m-d'))); ?>" required>
                            <?php $__errorArgs = ['fecha_estreno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Sinopsis -->
                        <div class="col-12">
                            <label class="form-label fw-bold">Sinopsis</label>
                            <textarea class="form-control <?php $__errorArgs = ['sinopsis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="sinopsis" rows="4" placeholder="Descripción de la película..."><?php echo e(old('sinopsis', $pelicula->sinopsis)); ?></textarea>
                            <?php $__errorArgs = ['sinopsis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Reparto -->
                        <div class="col-12">
                            <label class="form-label fw-bold">Reparto</label>
                            <textarea class="form-control <?php $__errorArgs = ['reparto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="reparto" rows="3" placeholder="Actores principales separados por comas..."><?php echo e(old('reparto', $pelicula->reparto)); ?></textarea>
                            <?php $__errorArgs = ['reparto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Poster Actual -->
                        <?php if($pelicula->poster): ?>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Poster Actual</label>
                            <div class="text-center">
                                <img src="<?php echo e(asset('storage/' . $pelicula->poster)); ?>" 
                                     alt="<?php echo e($pelicula->titulo); ?>" 
                                     class="img-thumbnail" 
                                     style="max-height: 200px;">
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Nuevo Poster -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold"><?php echo e($pelicula->poster ? 'Cambiar Poster' : 'Poster'); ?></label>
                            <input type="file" class="form-control <?php $__errorArgs = ['poster'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="poster" accept="image/*">
                            <div class="form-text">JPG, PNG, GIF. Máximo 2MB</div>
                            <?php $__errorArgs = ['poster'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- URL del Trailer -->
                        <div class="col-12">
                            <label class="form-label fw-bold">URL del Trailer (YouTube)</label>
                            <input type="url" class="form-control <?php $__errorArgs = ['trailer_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="trailer_url" value="<?php echo e(old('trailer_url', $pelicula->trailer_url)); ?>" 
                                   placeholder="https://www.youtube.com/embed/...">
                            <?php $__errorArgs = ['trailer_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Checkboxes -->
                        <div class="col-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="activa" value="1" 
                                               <?php echo e(old('activa', $pelicula->activa) ? 'checked' : ''); ?>>
                                        <label class="form-check-label">
                                            Película Activa
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="destacada" value="1" 
                                               <?php echo e(old('destacada', $pelicula->destacada) ? 'checked' : ''); ?>>
                                        <label class="form-check-label">
                                            Película Destacada
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Botones -->
                        <div class="col-12">
                            <hr>
                            <div class="d-flex justify-content-between">
                                <a href="<?php echo e(route('admin.peliculas.show', $pelicula)); ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Cancelar
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Actualizar Película
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/admin/peliculas/edit.blade.php ENDPATH**/ ?>