


<?php $__env->startSection('title', 'Checkout - Dulcería | Butaca del Salchicon'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-warning text-dark text-center">
                    <h3 class="mb-0">
                        <i class="fas fa-credit-card me-2"></i>PAGO DULCERÍA
                    </h3>
                    <p class="mb-0">Finaliza tu pedido de dulcería</p>
                </div>

                <div class="card-body p-4">
                    <div class="row">
                        <!-- Resumen del Pedido -->
                        <div class="col-md-6">
                            <h5 class="fw-bold mb-3">
                                <i class="fas fa-shopping-bag me-2"></i>Resumen del Pedido
                            </h5>
                            
                            <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoId => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex align-items-center mb-3 p-3 bg-light rounded">
                                    <?php if($item['imagen']): ?>
                                        <img src="<?php echo e(asset('storage/' . $item['imagen'])); ?>" 
                                             alt="<?php echo e($item['nombre']); ?>" 
                                             class="rounded me-3" 
                                             style="width: 60px; height: 60px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-secondary rounded me-3 d-flex align-items-center justify-content-center" 
                                             style="width: 60px; height: 60px;">
                                            <i class="fas fa-candy-cane text-white fs-4"></i>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1"><?php echo e($item['nombre']); ?></h6>
                                        <small class="text-muted">
                                            <?php echo e($item['cantidad']); ?>x <?php echo e(formatPrice($item['precio'])); ?>

                                        </small>
                                    </div>
                                    
                                    <div class="text-end">
                                        <strong><?php echo e(formatPrice($item['precio'] * $item['cantidad'])); ?></strong>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <hr>
                            
                            <div class="d-flex justify-content-between fw-bold fs-5">
                                <span>Total a Pagar:</span>
                                <span class="text-warning"><?php echo e(formatPrice($total)); ?></span>
                            </div>
                        </div>

                        <!-- Método de Pago -->
                        <div class="col-md-6">
                            <div class="bg-light p-3 rounded">
                                <h5 class="fw-bold mb-3">
                                    <i class="fas fa-credit-card me-2"></i>Método de Pago
                                </h5>
                                
                                <!-- Botones de métodos de pago -->
                                <button type="button" class="btn btn-outline-primary w-100 mb-2" id="btn-yape-dulceria">
                                    <img src="<?php echo e(asset('images/icons/yape.png')); ?>" alt="Yape" style="height: 20px;" class="me-2">
                                    Yape
                                </button>
                                
                                <div class="text-center my-2">
                                    <small class="text-muted">O elige tarjeta</small>
                                </div>

                                <div class="row g-2">
                                    <div class="col-6">
                                        <button type="button" class="btn btn-outline-secondary w-100" id="btn-visa-dulceria">
                                            <img src="<?php echo e(asset('images/icons/visa.png')); ?>" alt="Visa" style="height: 20px;">
                                        </button>
                                    </div>
                                    <div class="col-6">
                                        <button type="button" class="btn btn-outline-secondary w-100" id="btn-mastercard-dulceria">
                                            <img src="<?php echo e(asset('images/icons/mastercard.png')); ?>" alt="MasterCard" style="height: 20px;">
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Botón de Pago -->
                            <div class="mt-4">
                                <!-- Datos ocultos -->
                                <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoId => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" class="producto-hidden" 
                                           data-id="<?php echo e($productoId); ?>" 
                                           data-cantidad="<?php echo e($item['cantidad']); ?>"
                                           data-precio="<?php echo e($item['precio']); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" id="metodo_pago_dulceria" value="">
                                
                                <button type="button" id="btn-pagar-dulceria" class="btn btn-warning w-100" disabled>
                                    <i class="fas fa-shopping-cart me-2"></i>
                                    Pagar <?php echo e(formatPrice($total)); ?>

                                </button>
                            </div>

                            <div class="text-center mt-3">
                                <a href="<?php echo e(route('dulceria.carrito')); ?>" class="btn btn-link">
                                    <i class="fas fa-arrow-left me-1"></i>Volver al carrito
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    console.log('✅ Checkout dulcería cargado');
    
    // Manejar selección de método de pago
    $('#btn-yape-dulceria, #btn-visa-dulceria, #btn-mastercard-dulceria').click(function() {
        console.log('💳 Método seleccionado:', this.id);
        
        // Reset all buttons
        $('#btn-yape-dulceria, #btn-visa-dulceria, #btn-mastercard-dulceria')
            .removeClass('btn-primary btn-success')
            .addClass('btn-outline-primary btn-outline-secondary');
        
        // Activate selected button
        $(this).removeClass('btn-outline-primary btn-outline-secondary').addClass('btn-primary');
        
        // Set payment method
        let metodo = '';
        if (this.id === 'btn-yape-dulceria') metodo = 'yape';
        else if (this.id === 'btn-visa-dulceria') metodo = 'visa';
        else if (this.id === 'btn-mastercard-dulceria') metodo = 'mastercard';
        
        $('#metodo_pago_dulceria').val(metodo);
        $('#btn-pagar-dulceria').prop('disabled', false);
        
        console.log('✅ Método guardado:', metodo);
    });
    
    // Manejar pago
    $('#btn-pagar-dulceria').click(function() {
        console.log('🚀 Procesando pago dulcería...');
        
        let metodo = $('#metodo_pago_dulceria').val();
        
        if (!metodo) {
            alert('Por favor selecciona un método de pago');
            return;
        }
        
        // Cambiar botón a loading
        $(this).html('<i class="fas fa-spinner fa-spin me-2"></i>Procesando pago...').prop('disabled', true);
        
        // Crear formulario dinámico
        let form = $('<form>', {
            method: 'POST',
            action: '<?php echo e(route("dulceria.procesar-pedido")); ?>'
        });
        
        // Agregar CSRF
        form.append($('<input>', {
            type: 'hidden',
            name: '_token',
            value: '<?php echo e(csrf_token()); ?>'
        }));
        
        // Agregar método de pago
        form.append($('<input>', {
            type: 'hidden',
            name: 'metodo_pago',
            value: metodo
        }));
        
        console.log('📤 Enviando pedido dulcería...');
        
        // Enviar
        $('body').append(form);
        form.submit();
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/dulceria/checkout.blade.php ENDPATH**/ ?>