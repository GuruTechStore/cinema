


<?php $__env->startSection('title', 'Nueva Película'); ?>
<?php $__env->startSection('page-title', 'Nueva Película'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.peliculas.index')); ?>">Películas</a></li>
<li class="breadcrumb-item active">Nueva</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-12">
        <form method="POST" action="<?php echo e(route('admin.peliculas.store')); ?>" enctype="multipart/form-data" id="peliculaForm">
            <?php echo csrf_field(); ?>
            
            <!-- Información Básica -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-film me-2"></i>Información Básica
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <!-- Título -->
                        <div class="col-md-8">
                            <label class="form-label fw-bold">Título *</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="titulo" value="<?php echo e(old('titulo')); ?>" required placeholder="Ej: Deadpool & Wolverine">
                            <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Clasificación -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Clasificación *</label>
                            <select class="form-select <?php $__errorArgs = ['clasificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="clasificacion" required>
                                <option value="">Seleccionar</option>
                                <option value="G" <?php echo e(old('clasificacion') == 'G' ? 'selected' : ''); ?>>G - General</option>
                                <option value="PG" <?php echo e(old('clasificacion') == 'PG' ? 'selected' : ''); ?>>PG - Parental Guidance</option>
                                <option value="PG-13" <?php echo e(old('clasificacion') == 'PG-13' ? 'selected' : ''); ?>>PG-13</option>
                                <option value="R" <?php echo e(old('clasificacion') == 'R' ? 'selected' : ''); ?>>R - Restricted</option>
                                <option value="NC-17" <?php echo e(old('clasificacion') == 'NC-17' ? 'selected' : ''); ?>>NC-17</option>
                            </select>
                            <?php $__errorArgs = ['clasificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Director -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Director *</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="director" value="<?php echo e(old('director')); ?>" required placeholder="Ej: Shawn Levy">
                            <?php $__errorArgs = ['director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Género -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Género *</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['genero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="genero" value="<?php echo e(old('genero')); ?>" required 
                                   placeholder="Ej: Acción, Comedia, Ciencia Ficción">
                            <?php $__errorArgs = ['genero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Duración -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Duración (minutos) *</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['duracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="duracion" value="<?php echo e(old('duracion')); ?>" required min="1" max="300"
                                   placeholder="120">
                            <?php $__errorArgs = ['duracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Idioma -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Idioma</label>
                            <select class="form-select <?php $__errorArgs = ['idioma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="idioma">
                                <option value="">Seleccionar</option>
                                <option value="Español" <?php echo e(old('idioma') == 'Español' ? 'selected' : ''); ?>>Español</option>
                                <option value="Inglés" <?php echo e(old('idioma') == 'Inglés' ? 'selected' : ''); ?>>Inglés</option>
                                <option value="Inglés/Español" <?php echo e(old('idioma') == 'Inglés/Español' ? 'selected' : ''); ?>>Inglés/Español</option>
                            </select>
                            <?php $__errorArgs = ['idioma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Fecha de Estreno -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Fecha de Estreno *</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['fecha_estreno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="fecha_estreno" value="<?php echo e(old('fecha_estreno')); ?>" required
                                   min="<?php echo e(date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['fecha_estreno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Descripción y Sinopsis -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-align-left me-2"></i>Descripción y Detalles
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <!-- Descripción Corta -->
                        <div class="col-12">
                            <label class="form-label fw-bold">Descripción Corta</label>
                            <textarea class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="descripcion" rows="3" 
                                      placeholder="Descripción breve que aparecerá en las tarjetas (máximo 200 caracteres)"
                                      maxlength="200"><?php echo e(old('descripcion')); ?></textarea>
                            <div class="form-text">Máximo 200 caracteres. Aparece en las tarjetas de película.</div>
                            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Sinopsis -->
                        <div class="col-12">
                            <label class="form-label fw-bold">Sinopsis Completa</label>
                            <textarea class="form-control <?php $__errorArgs = ['sinopsis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="sinopsis" rows="4" 
                                      placeholder="Sinopsis detallada de la película"><?php echo e(old('sinopsis')); ?></textarea>
                            <div class="form-text">Descripción completa que aparece en la página de detalles.</div>
                            <?php $__errorArgs = ['sinopsis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Reparto -->
                        <div class="col-12">
                            <label class="form-label fw-bold">Reparto Principal</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['reparto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="reparto" value="<?php echo e(old('reparto')); ?>" 
                                   placeholder="Ej: Ryan Reynolds, Hugh Jackman, Emma Corrin">
                            <div class="form-text">Separar nombres con comas.</div>
                            <?php $__errorArgs = ['reparto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Multimedia -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-image me-2"></i>Multimedia
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <!-- Poster -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Poster de la Película</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['poster'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="poster" accept="image/*" id="posterInput">
                            <div class="form-text">Formatos: JPG, PNG, WEBP. Máximo 2MB. Tamaño recomendado: 300x450px</div>
                            <?php $__errorArgs = ['poster'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            <!-- Vista previa del poster -->
                            <div class="mt-3" id="posterPreview" style="display: none;">
                                <img id="posterImage" src="" alt="Vista previa" class="img-thumbnail" style="max-width: 200px;">
                            </div>
                        </div>

                        <!-- Trailer -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold">URL del Trailer (YouTube)</label>
                            <input type="url" class="form-control <?php $__errorArgs = ['trailer_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="trailer_url" value="<?php echo e(old('trailer_url')); ?>" 
                                   placeholder="https://www.youtube.com/watch?v=...">
                            <div class="form-text">URL de YouTube del trailer oficial.</div>
                            <?php $__errorArgs = ['trailer_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Configuración -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-cog me-2"></i>Configuración
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <!-- Estado -->
                        <div class="col-md-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="activa" value="1" 
                                       id="activaSwitch" <?php echo e(old('activa', true) ? 'checked' : ''); ?>>
                                <label class="form-check-label fw-bold" for="activaSwitch">
                                    Película Activa
                                </label>
                            </div>
                            <div class="form-text">Si está desactivada, no aparecerá en la web pública.</div>
                        </div>

                        <!-- Destacada -->
                        <div class="col-md-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="destacada" value="1" 
                                       id="destacadaSwitch" <?php echo e(old('destacada') ? 'checked' : ''); ?>>
                                <label class="form-check-label fw-bold" for="destacadaSwitch">
                                    Película Destacada
                                </label>
                            </div>
                            <div class="form-text">Aparecerá en la sección de películas destacadas.</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Programación Inmediata (Opcional) -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-calendar-plus me-2"></i>Programación Inicial (Opcional)
                    </h5>
                </div>
                <div class="card-body">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="programarAhora">
                        <label class="form-check-label fw-bold" for="programarAhora">
                            Programar funciones inmediatamente después de crear la película
                        </label>
                    </div>
                    
                    <div id="programacionSection" style="display: none;">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>Nota:</strong> Después de crear la película, serás redirigido automáticamente 
                            al formulario de programación donde podrás asignar cines, salas y horarios.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Botones -->
            <div class="card">
                <div class="card-body">
                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-save me-2"></i>Crear Película
                        </button>
                        <a href="<?php echo e(route('admin.peliculas.index')); ?>" class="btn btn-outline-secondary btn-lg">
                            <i class="fas fa-times me-2"></i>Cancelar
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.form-label.fw-bold {
    color: #495057;
}

.card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
}

.form-text {
    font-size: 0.875em;
    color: #6c757d;
}

#posterPreview img {
    border: 2px solid #dee2e6;
    border-radius: 8px;
}

.form-check-input:checked {
    background-color: #0d6efd;
    border-color: #0d6efd;
}

.btn-lg {
    padding: 0.75rem 2rem;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Vista previa del poster
    const posterInput = document.getElementById('posterInput');
    const posterPreview = document.getElementById('posterPreview');
    const posterImage = document.getElementById('posterImage');
    
    posterInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                posterImage.src = e.target.result;
                posterPreview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            posterPreview.style.display = 'none';
        }
    });
    
    // Mostrar/ocultar sección de programación
    const programarAhora = document.getElementById('programarAhora');
    const programacionSection = document.getElementById('programacionSection');
    
    programarAhora.addEventListener('change', function() {
        programacionSection.style.display = this.checked ? 'block' : 'none';
    });
    
    // Validación del formulario
    const form = document.getElementById('peliculaForm');
    form.addEventListener('submit', function(e) {
        // Aquí puedes agregar validaciones adicionales si es necesario
        const titulo = document.querySelector('input[name="titulo"]').value.trim();
        if (titulo.length < 2) {
            e.preventDefault();
            alert('El título debe tener al menos 2 caracteres.');
            return false;
        }
        
        // Si está marcado programar ahora, agregar un campo hidden
        if (programarAhora.checked) {
            const hiddenInput = document.createElement('input');
            hiddenInput.type = 'hidden';
            hiddenInput.name = 'programar_inmediatamente';
            hiddenInput.value = '1';
            form.appendChild(hiddenInput);
        }
    });
    
    // Auto-completar campos basado en el título (opcional)
    const tituloInput = document.querySelector('input[name="titulo"]');
    tituloInput.addEventListener('blur', function() {
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/admin/peliculas/create.blade.php ENDPATH**/ ?>