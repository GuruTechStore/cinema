


<?php $__env->startSection('title', 'Gestión de Dulcería'); ?>
<?php $__env->startSection('page-title', 'Productos de Dulcería'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active">Dulcería</li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* PAGINACIÓN ARREGLADA - SIN SVG GIGANTES */
.pagination-sm .page-link {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
    line-height: 1.5;
    border-radius: 0.25rem;
    min-width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 1px;
    border: 1px solid #dee2e6;
    color: #6c757d;
    background-color: #fff;
    text-decoration: none;
}

.pagination-sm .page-link:hover {
    z-index: 2;
    color: #0a58ca;
    background-color: #e9ecef;
    border-color: #dee2e6;
}

.pagination-sm .page-item.active .page-link {
    z-index: 3;
    color: #fff;
    background-color: #0d6efd;
    border-color: #0d6efd;
}

.pagination-sm .page-item.disabled .page-link {
    color: #6c757d;
    pointer-events: none;
    background-color: #fff;
    border-color: #dee2e6;
    opacity: 0.65;
}

.pagination {
    margin-bottom: 0;
    gap: 0;
}

/* Responsive */
@media (max-width: 576px) {
    .pagination-sm .page-link {
        min-width: 28px;
        height: 28px;
        font-size: 0.75rem;
        padding: 0.125rem 0.25rem;
    }
    
    .pagination .page-item:not(.active):not(.disabled):not(:first-child):not(:last-child):not(:nth-child(2)):not(:nth-last-child(2)) {
        display: none;
    }
}

/* Estilos para las cards */
.producto-card {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    border: 1px solid #e3e6f0;
}

.producto-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.producto-image {
    height: 200px;
    object-fit: cover;
    border-radius: 0.375rem 0.375rem 0 0;
}

.badge-estado {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
}

.filtros-container {
    background: #f8f9fc;
    border-radius: 0.375rem;
    padding: 1rem;
    margin-bottom: 1.5rem;
    border: 1px solid #e3e6f0;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Estadísticas principales -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Productos</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($totalProductos); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-boxes fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Productos Activos</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($productosActivos); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Ventas Hoy</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($ventasHoy); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Ingresos Totales</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(formatPrice($ingresosTotales)); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-candy-cane me-2"></i>Gestión de Productos
                </h6>
                <a href="<?php echo e(route('admin.dulceria.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus me-2"></i>Nuevo Producto
                </a>
            </div>
            
            <div class="card-body">
                <!-- Filtros -->
                <div class="filtros-container">
                    <form method="GET" action="<?php echo e(route('admin.dulceria.index')); ?>" id="filtros-form">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label small text-muted">Categoría</label>
                                <select class="form-select form-select-sm" name="categoria" onchange="this.form.submit()">
                                    <option value="">Todas las categorías</option>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->id); ?>" 
                                                <?php echo e(request('categoria') == $categoria->id ? 'selected' : ''); ?>>
                                            <?php echo e($categoria->nombre); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small text-muted">Estado</label>
                                <select class="form-select form-select-sm" name="estado" onchange="this.form.submit()">
                                    <option value="">Todos los estados</option>
                                    <option value="activo" <?php echo e(request('estado') == 'activo' ? 'selected' : ''); ?>>Activos</option>
                                    <option value="inactivo" <?php echo e(request('estado') == 'inactivo' ? 'selected' : ''); ?>>Inactivos</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small text-muted">Buscar producto</label>
                                <input type="text" class="form-control form-control-sm" name="buscar" 
                                       value="<?php echo e(request('buscar')); ?>" placeholder="Nombre del producto..."
                                       onkeypress="if(event.key==='Enter') this.form.submit()">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small text-muted">&nbsp;</label>
                                <div class="d-flex gap-1">
                                    <button type="submit" class="btn btn-outline-primary btn-sm flex-fill">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <a href="<?php echo e(route('admin.dulceria.index')); ?>" class="btn btn-outline-secondary btn-sm">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Grid de productos -->
                <?php if($productos->count() > 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                            <div class="card producto-card h-100">
                                <div class="position-relative">
                                    <img src="<?php echo e(getDulceriaImageUrl($producto->imagen, $producto->nombre)); ?>" 
                                         class="card-img-top producto-image" 
                                         alt="<?php echo e($producto->nombre); ?>"
                                         onerror="this.src='<?php echo e(asset('images/dulceria/placeholder.jpg')); ?>'">
                                    
                                    <div class="position-absolute top-0 end-0 p-2">
                                        <span class="badge badge-estado <?php echo e($producto->activo ? 'bg-success' : 'bg-danger'); ?>">
                                            <?php echo e($producto->activo ? 'Activo' : 'Inactivo'); ?>

                                        </span>
                                    </div>
                                    
                                    <?php if($producto->es_combo): ?>
                                    <div class="position-absolute top-0 start-0 p-2">
                                        <span class="badge bg-warning text-dark">
                                            <i class="fas fa-gift me-1"></i>Combo
                                        </span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="card-body d-flex flex-column">
                                    <h6 class="card-title font-weight-bold mb-2"><?php echo e($producto->nombre); ?></h6>
                                    <p class="card-text text-muted small mb-2">
                                        <?php echo e($producto->categoria->nombre); ?>

                                    </p>
                                    <p class="card-text text-muted small flex-grow-1">
                                        <?php echo e(Str::limit($producto->descripcion, 80)); ?>

                                    </p>
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <span class="h5 mb-0 text-primary font-weight-bold">
                                            <?php echo e(formatPrice($producto->precio)); ?>

                                        </span>
                                        <small class="text-muted">
                                            ID: #<?php echo e($producto->id); ?>

                                        </small>
                                    </div>
                                    
                                    <div class="d-flex gap-1">
                                        <a href="<?php echo e(route('admin.dulceria.show', $producto)); ?>" 
                                           class="btn btn-outline-info btn-sm flex-fill">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.dulceria.edit', $producto)); ?>" 
                                           class="btn btn-outline-primary btn-sm flex-fill">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form method="POST" action="<?php echo e(route('admin.dulceria.toggle-status', $producto)); ?>" 
                                              class="d-inline flex-fill">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" 
                                                    class="btn btn-outline-<?php echo e($producto->activo ? 'warning' : 'success'); ?> btn-sm w-100"
                                                    onclick="return confirm('¿Cambiar estado del producto?')">
                                                <i class="fas fa-<?php echo e($producto->activo ? 'pause' : 'play'); ?>"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- PAGINACIÓN PERSONALIZADA SIN SVG -->
                    <?php if($productos->hasPages()): ?>
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <div class="text-muted small">
                                Mostrando <?php echo e($productos->firstItem()); ?> a <?php echo e($productos->lastItem()); ?> 
                                de <?php echo e($productos->total()); ?> resultados
                            </div>
                            <div>
                                <nav aria-label="Page Navigation">
                                    <ul class="pagination pagination-sm mb-0">
                                        
                                        <?php if($productos->onFirstPage()): ?>
                                            <li class="page-item disabled">
                                                <span class="page-link">‹</span>
                                            </li>
                                        <?php else: ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo e($productos->previousPageUrl()); ?>" rel="prev">‹</a>
                                            </li>
                                        <?php endif; ?>

                                        
                                        <?php
                                            $start = max($productos->currentPage() - 2, 1);
                                            $end = min($start + 4, $productos->lastPage());
                                            $start = max($end - 4, 1);
                                        ?>

                                        <?php if($start > 1): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo e($productos->url(1)); ?>">1</a>
                                            </li>
                                            <?php if($start > 2): ?>
                                                <li class="page-item disabled">
                                                    <span class="page-link">...</span>
                                                </li>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php for($page = $start; $page <= $end; $page++): ?>
                                            <?php if($page == $productos->currentPage()): ?>
                                                <li class="page-item active">
                                                    <span class="page-link"><?php echo e($page); ?></span>
                                                </li>
                                            <?php else: ?>
                                                <li class="page-item">
                                                    <a class="page-link" href="<?php echo e($productos->url($page)); ?>"><?php echo e($page); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endfor; ?>

                                        <?php if($end < $productos->lastPage()): ?>
                                            <?php if($end < $productos->lastPage() - 1): ?>
                                                <li class="page-item disabled">
                                                    <span class="page-link">...</span>
                                                </li>
                                            <?php endif; ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo e($productos->url($productos->lastPage())); ?>"><?php echo e($productos->lastPage()); ?></a>
                                            </li>
                                        <?php endif; ?>

                                        
                                        <?php if($productos->hasMorePages()): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo e($productos->nextPageUrl()); ?>" rel="next">›</a>
                                            </li>
                                        <?php else: ?>
                                            <li class="page-item disabled">
                                                <span class="page-link">›</span>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <div class="text-muted">
                            <i class="fas fa-candy-cane fa-3x mb-3 text-gray-300"></i>
                            <h5 class="text-gray-600">No hay productos registrados</h5>
                            <p class="text-gray-500">
                                <?php if(request()->hasAny(['categoria', 'estado', 'buscar'])): ?>
                                    No se encontraron productos con los filtros aplicados.
                                    <br>
                                    <a href="<?php echo e(route('admin.dulceria.index')); ?>" class="btn btn-outline-secondary btn-sm mt-2">
                                        <i class="fas fa-times me-1"></i>Limpiar filtros
                                    </a>
                                <?php else: ?>
                                    Comienza agregando tu primer producto de dulcería
                                <?php endif; ?>
                            </p>
                            <?php if(!request()->hasAny(['categoria', 'estado', 'buscar'])): ?>
                                <a href="<?php echo e(route('admin.dulceria.create')); ?>" class="btn btn-primary">
                                    <i class="fas fa-plus me-2"></i>Crear Primer Producto
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Auto-submit en filtros
    $('select[name="categoria"], select[name="estado"]').change(function() {
        $('#filtros-form').submit();
    });
    
    // Buscar con Enter
    $('input[name="buscar"]').keypress(function(e) {
        if (e.which === 13) {
            $('#filtros-form').submit();
        }
    });
    
    // Confirmación de cambios de estado
    $('form[action*="toggle-status"]').submit(function(e) {
        const isActive = $(this).find('button i').hasClass('fa-pause');
        const action = isActive ? 'desactivar' : 'activar';
        const productName = $(this).closest('.card').find('.card-title').text().trim();
        
        if (!confirm(`¿Estás seguro de ${action} el producto "${productName}"?`)) {
            e.preventDefault();
            return false;
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/admin/dulceria/index.blade.php ENDPATH**/ ?>