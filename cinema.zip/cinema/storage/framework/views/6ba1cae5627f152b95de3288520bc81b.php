


<?php $__env->startSection('title', 'Carrito de Dulcería - Butaca del Salchicon'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-warning text-dark">
                        <h4 class="mb-0">
                            <i class="fas fa-shopping-cart me-2"></i>Tu Carrito de Dulcería
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php if(!empty($carrito)): ?>
                            <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoId => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row align-items-center border-bottom py-3" data-producto="<?php echo e($productoId); ?>">
                                <div class="col-md-2">
                                    <img src="<?php echo e($item['imagen'] ? asset('storage/' . $item['imagen']) : asset('images/dulceria/placeholder-dulceria.jpg')); ?>" 
                                         class="img-fluid rounded" alt="<?php echo e($item['nombre']); ?>">
                                </div>
                                <div class="col-md-4">
                                    <h6 class="fw-bold"><?php echo e($item['nombre']); ?></h6>
                                    <p class="text-muted small mb-0">Precio unitario: <?php echo e(formatPrice($item['precio'])); ?></p>
                                </div>
                                <div class="col-md-3">
                                    <div class="input-group">
                                        <button class="btn btn-outline-secondary btn-sm btn-minus" 
                                                data-producto="<?php echo e($productoId); ?>">-</button>
                                        <input type="number" class="form-control form-control-sm text-center cantidad-input" 
                                               value="<?php echo e($item['cantidad']); ?>" min="1" max="10" 
                                               data-producto="<?php echo e($productoId); ?>" data-precio="<?php echo e($item['precio']); ?>">
                                        <button class="btn btn-outline-secondary btn-sm btn-plus" 
                                                data-producto="<?php echo e($productoId); ?>">+</button>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <span class="fw-bold subtotal" data-producto="<?php echo e($productoId); ?>">
                                        <?php echo e(formatPrice($item['precio'] * $item['cantidad'])); ?>

                                    </span>
                                </div>
                                <div class="col-md-1">
                                    <button class="btn btn-danger btn-sm btn-eliminar" 
                                            data-producto="<?php echo e($productoId); ?>"
                                            title="Eliminar producto">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="mt-3">
                                <div class="d-flex justify-content-between">
                                    <button class="btn btn-outline-danger" onclick="limpiarCarrito()">
                                        <i class="fas fa-trash me-2"></i>Vaciar Carrito
                                    </button>
                                    <div class="text-end">
                                        <p class="mb-1">Subtotal: <span id="subtotal-carrito"><?php echo e(formatPrice($total)); ?></span></p>
                                        <p class="mb-0 fw-bold fs-5">Total: <span id="total-carrito"><?php echo e(formatPrice($total)); ?></span></p>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-shopping-cart display-1 text-muted mb-3"></i>
                                <h5 class="text-muted">Tu carrito está vacío</h5>
                                <p class="text-muted">Agrega algunos productos deliciosos de nuestra dulcería</p>
                                <a href="<?php echo e(route('dulceria.index')); ?>" class="btn btn-warning">
                                    <i class="fas fa-candy-cane me-2"></i>Ir a Dulcería
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Resumen del pedido -->
            <?php if(!empty($carrito)): ?>
            <div class="col-lg-4">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-receipt me-2"></i>Resumen del Pedido
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between small mb-1">
                                <span><?php echo e($item['nombre']); ?> (<?php echo e($item['cantidad']); ?>x)</span>
                                <span><?php echo e(formatPrice($item['precio'] * $item['cantidad'])); ?></span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between fw-bold fs-5">
                            <span>Total:</span>
                            <span id="total-final"><?php echo e(formatPrice($total)); ?></span>
                        </div>

                        <a href="<?php echo e(route('dulceria.checkout')); ?>" class="btn btn-warning w-100 mt-4">
                            <i class="fas fa-credit-card me-2"></i>Proceder al Pago
                        </a>

                        <a href="<?php echo e(route('dulceria.index')); ?>" class="btn btn-outline-primary w-100 mt-2">
                            <i class="fas fa-arrow-left me-2"></i>Seguir Comprando
                        </a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    console.log('🛒 Carrito de dulcería cargado');
    
    // Actualizar cantidad
    $('.btn-plus, .btn-minus').click(function() {
        const productoId = $(this).data('producto');
        const input = $(`.cantidad-input[data-producto="${productoId}"]`);
        let cantidad = parseInt(input.val());
        
        if ($(this).hasClass('btn-plus') && cantidad < 10) {
            cantidad++;
        } else if ($(this).hasClass('btn-minus') && cantidad > 1) {
            cantidad--;
        }
        
        input.val(cantidad);
        actualizarCarrito(productoId, cantidad);
    });

    // Cambio directo en input
    $('.cantidad-input').change(function() {
        const productoId = $(this).data('producto');
        let cantidad = parseInt($(this).val());
        
        if (cantidad < 1) cantidad = 1;
        if (cantidad > 10) cantidad = 10;
        
        $(this).val(cantidad);
        actualizarCarrito(productoId, cantidad);
    });

    // Eliminar producto - VERSIÓN CORREGIDA
    $('.btn-eliminar').click(function(e) {
        e.preventDefault();
        const productoId = $(this).data('producto');
        
        console.log('🗑️ Intentando eliminar producto:', productoId);
        
        if (confirm('¿Eliminar este producto del carrito?')) {
            // Mostrar loading
            showLoadingSpinner($(this));
            
            // Usar la ruta nombrada correcta
            window.location.href = `<?php echo e(route('dulceria.eliminar-carrito', ':id')); ?>`.replace(':id', productoId);
        }
    });

    function actualizarCarrito(productoId, cantidad) {
        $.post('<?php echo e(route("dulceria.actualizar-carrito")); ?>', {
            producto_id: productoId,
            cantidad: cantidad,
            _token: '<?php echo e(csrf_token()); ?>'
        })
        .done(function(response) {
            console.log('✅ Carrito actualizado');
            location.reload();
        })
        .fail(function(xhr, status, error) {
            console.error('❌ Error al actualizar carrito:', error);
            showAlert('Error al actualizar el carrito', 'danger');
        });
    }
    
    // Función para limpiar carrito completo
    window.limpiarCarrito = function() {
        if (confirm('¿Estás seguro de vaciar todo el carrito?')) {
            // Aquí puedes agregar la funcionalidad para limpiar todo el carrito
            // Por ahora, redirigir a dulcería
            window.location.href = '<?php echo e(route("dulceria.index")); ?>';
        }
    };
    
    // Función para mostrar spinner de carga
    function showLoadingSpinner(element) {
        const originalHtml = element.html();
        element.data('original-html', originalHtml);
        element.html('<i class="fas fa-spinner fa-spin"></i>');
        element.prop('disabled', true);
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/dulceria/carrito.blade.php ENDPATH**/ ?>