


<?php $__env->startSection('title', $pelicula->titulo); ?>
<?php $__env->startSection('page-title', 'Detalle de Película'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.peliculas.index')); ?>">Películas</a></li>
<li class="breadcrumb-item active"><?php echo e($pelicula->titulo); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-actions'); ?>
<div class="btn-group">
    <a href="<?php echo e(route('admin.peliculas.edit', $pelicula)); ?>" class="btn btn-admin btn-warning">
        <i class="fas fa-edit me-2"></i>Editar
    </a>
    <a href="<?php echo e(route('admin.peliculas.programar-funciones', $pelicula)); ?>" class="btn btn-admin btn-success">
        <i class="fas fa-calendar-plus me-2"></i>Programar Funciones
    </a>
    <button type="button" class="btn btn-admin btn-danger" data-bs-toggle="modal" data-bs-target="#eliminarModal">
        <i class="fas fa-trash me-2"></i>Eliminar
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Información Principal -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-film me-2"></i>Información de la Película
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <td class="fw-bold">Título:</td>
                                <td><?php echo e($pelicula->titulo); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Director:</td>
                                <td><?php echo e($pelicula->director); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Género:</td>
                                <td><?php echo e($pelicula->genero); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Duración:</td>
                                <td><?php echo e($pelicula->getDuracionFormateada()); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Clasificación:</td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo e($pelicula->clasificacion); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Fecha de Estreno:</td>
                                <td><?php echo e($pelicula->fecha_estreno->format('d/m/Y')); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <td class="fw-bold">Estado:</td>
                                <td>
                                    <?php if($pelicula->activa): ?>
                                        <span class="badge bg-success">Activa</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactiva</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Destacada:</td>
                                <td>
                                    <?php if($pelicula->destacada): ?>
                                        <span class="badge bg-warning text-dark">Sí</span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-dark">No</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Idioma:</td>
                                <td><?php echo e($pelicula->idioma ?? 'No especificado'); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Creado:</td>
                                <td><?php echo e($pelicula->created_at->format('d/m/Y H:i')); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Actualizado:</td>
                                <td><?php echo e($pelicula->updated_at->format('d/m/Y H:i')); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <?php if($pelicula->sinopsis): ?>
                <div class="mt-4">
                    <h6 class="fw-bold">Sinopsis:</h6>
                    <p class="text-muted"><?php echo e($pelicula->sinopsis); ?></p>
                </div>
                <?php endif; ?>

                <?php if($pelicula->reparto): ?>
                <div class="mt-4">
                    <h6 class="fw-bold">Reparto:</h6>
                    <p class="text-muted"><?php echo e($pelicula->reparto); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Funciones Programadas -->
        <div class="card mt-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-calendar me-2"></i>Funciones Programadas
                </h5>
                <a href="<?php echo e(route('admin.peliculas.programar-funciones', $pelicula)); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus me-1"></i>Nueva Función
                </a>
            </div>
            <div class="card-body">
                <?php if($pelicula->funciones->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Hora</th>
                                    <th>Sala</th>
                                    <th>Cine</th>
                                    <th>Precio</th>
                                    <th>Reservas</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pelicula->funciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($funcion->fecha_funcion ? $funcion->fecha_funcion->format('d/m/Y') : 'Sin fecha'); ?></td>
                                    <td><?php echo e($funcion->hora_funcion ? $funcion->hora_funcion->format('H:i') : 'Sin hora'); ?></td>
                                    <td><?php echo e($funcion->sala->nombre ?? 'Sin sala'); ?></td>
                                    <td><?php echo e($funcion->sala->cine->nombre ?? 'Sin cine'); ?></td>
                                    <td>S/ <?php echo e(number_format($funcion->precio ?? 0, 2)); ?></td>
                                    <td><?php echo e($funcion->reservas->count()); ?></td>
                                    <td>
                                        <?php if($funcion->fecha_funcion && $funcion->fecha_funcion->isPast()): ?>
                                            <span class="badge bg-secondary">Finalizada</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Activa</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-calendar-times display-1 text-muted mb-3"></i>
                        <h6 class="text-muted">No hay funciones programadas</h6>
                        <p class="text-muted">Programa la primera función de esta película</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- Poster -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-image me-2"></i>Poster
                </h5>
            </div>
            <div class="card-body text-center">
                <img src="<?php echo e($pelicula->poster ? asset('storage/' . $pelicula->poster) : asset('images/posters/default.jpg')); ?>" 
                     alt="<?php echo e($pelicula->titulo); ?>" 
                     class="img-fluid rounded shadow"
                     style="max-height: 400px;">
            </div>
        </div>

        <!-- Trailer -->
        <?php if($pelicula->trailer_url): ?>
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-play-circle me-2"></i>Trailer
                </h5>
            </div>
            <div class="card-body">
                <div class="ratio ratio-16x9">
                    <iframe src="<?php echo e($pelicula->trailer_url); ?>" 
                            title="Trailer <?php echo e($pelicula->titulo); ?>"
                            allowfullscreen></iframe>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Estadísticas -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2"></i>Estadísticas
                </h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-6">
                        <div class="border-end">
                            <h4 class="mb-0"><?php echo e($pelicula->funciones->count()); ?></h4>
                            <small class="text-muted">Funciones</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <h4 class="mb-0"><?php echo e($pelicula->funciones->sum(function($f) { return $f->reservas->count(); })); ?></h4>
                        <small class="text-muted">Reservas</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Eliminar -->
<div class="modal fade" id="eliminarModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Eliminación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que deseas eliminar la película <strong><?php echo e($pelicula->titulo); ?></strong>?</p>
                <p class="text-danger"><small>Esta acción no se puede deshacer y también eliminará todas las funciones asociadas.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form method="POST" action="<?php echo e(route('admin.peliculas.destroy', $pelicula)); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/admin/peliculas/show.blade.php ENDPATH**/ ?>