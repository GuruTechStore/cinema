


<?php $__env->startSection('title', 'Editar Producto'); ?>
<?php $__env->startSection('page-title', 'Editar: ' . $dulceria->nombre); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dulceria.index')); ?>">Dulcería</a></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dulceria.show', $dulceria)); ?>"><?php echo e($dulceria->nombre); ?></a></li>
<li class="breadcrumb-item active">Editar</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-edit me-2"></i>Editar Producto
                </h5>
                <span class="badge <?php echo e($dulceria->activo ? 'bg-success' : 'bg-danger'); ?>">
                    <?php echo e($dulceria->activo ? 'Activo' : 'Inactivo'); ?>

                </span>
            </div>
            
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.dulceria.update', $dulceria)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="row g-3">
                        <!-- Imagen actual (si existe) -->
                        <?php if($dulceria->imagen): ?>
                        <div class="col-12">
                            <label class="form-label fw-bold">Imagen Actual</label>
                            <div class="mb-3">
                                <img src="<?php echo e(asset('storage/' . $dulceria->imagen)); ?>" 
                                     alt="<?php echo e($dulceria->nombre); ?>" 
                                     class="img-thumbnail" 
                                     style="max-width: 200px; max-height: 200px;">
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Nombre -->
                        <div class="col-md-8">
                            <label class="form-label fw-bold">Nombre del Producto *</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="nombre" value="<?php echo e(old('nombre', $dulceria->nombre)); ?>" required
                                   placeholder="Ej: Canchita Grande">
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Categoría -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Categoría *</label>
                            <select class="form-select <?php $__errorArgs = ['categoria_dulceria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    name="categoria_dulceria_id" required>
                                <option value="">Seleccionar categoría</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categoria->id); ?>" 
                                            <?php echo e(old('categoria_dulceria_id', $dulceria->categoria_dulceria_id) == $categoria->id ? 'selected' : ''); ?>>
                                        <?php echo e($categoria->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['categoria_dulceria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Descripción -->
                        <div class="col-12">
                            <label class="form-label fw-bold">Descripción</label>
                            <textarea class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="descripcion" rows="3"
                                      placeholder="Descripción del producto (opcional)"><?php echo e(old('descripcion', $dulceria->descripcion)); ?></textarea>
                            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Precio -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Precio (S/) *</label>
                            <div class="input-group">
                                <span class="input-group-text">S/</span>
                                <input type="number" step="0.01" min="0" 
                                       class="form-control <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       name="precio" value="<?php echo e(old('precio', $dulceria->precio)); ?>" required
                                       placeholder="0.00">
                            </div>
                            <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Tipo de producto -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Tipo de Producto</label>
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" 
                                       name="es_combo" id="es_combo" 
                                       <?php echo e(old('es_combo', $dulceria->es_combo) ? 'checked' : ''); ?>>
                                <label class="form-check-label fw-bold" for="es_combo">
                                    Es un Combo
                                </label>
                                <small class="form-text text-muted d-block">
                                    Marca si este producto es un combo o paquete
                                </small>
                            </div>
                        </div>

                        <!-- Estado -->
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Estado</label>
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" 
                                       name="activo" id="activo"
                                       <?php echo e(old('activo', $dulceria->activo) ? 'checked' : ''); ?>>
                                <label class="form-check-label fw-bold" for="activo">
                                    Producto Activo
                                </label>
                                <small class="form-text text-muted d-block">
                                    Solo productos activos aparecen en la dulcería
                                </small>
                            </div>
                        </div>

                        <!-- Nueva imagen -->
                        <div class="col-12">
                            <label class="form-label fw-bold">Cambiar Imagen</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="imagen" accept="image/*" id="imagen-input">
                            <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="form-text text-muted">
                                Dejar vacío para mantener la imagen actual. Formatos: JPG, PNG, GIF. Máximo: 2MB
                            </small>
                            
                            <!-- Preview de nueva imagen -->
                            <div id="imagen-preview" class="mt-3" style="display: none;">
                                <strong>Nueva imagen:</strong><br>
                                <img id="preview-img" src="" alt="Preview" 
                                     class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                            </div>
                        </div>

                        <!-- Información adicional -->
                        <div class="col-12">
                            <div class="alert alert-info">
                                <h6><i class="fas fa-info-circle me-2"></i>Información del Producto</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-1"><strong>Creado:</strong> <?php echo e($dulceria->created_at->format('d/m/Y H:i')); ?></p>
                                        <p class="mb-1"><strong>ID:</strong> #<?php echo e($dulceria->id); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-1"><strong>Última modificación:</strong> <?php echo e($dulceria->updated_at->format('d/m/Y H:i')); ?></p>
                                        <p class="mb-1"><strong>Categoría actual:</strong> <?php echo e($dulceria->categoria->nombre); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Botones -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="d-flex justify-content-between">
                                <a href="<?php echo e(route('admin.dulceria.show', $dulceria)); ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Volver
                                </a>
                                
                                <div>
                                    <button type="reset" class="btn btn-outline-warning me-2">
                                        <i class="fas fa-undo me-2"></i>Restaurar
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Guardar Cambios
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Acciones adicionales -->
        <div class="card mt-4">
            <div class="card-header bg-warning text-dark">
                <h6 class="mb-0">
                    <i class="fas fa-cogs me-2"></i>Acciones Adicionales
                </h6>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <form method="POST" action="<?php echo e(route('admin.dulceria.toggle-status', $dulceria)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-<?php echo e($dulceria->activo ? 'warning' : 'success'); ?> w-100"
                                    onclick="return confirm('¿Cambiar estado del producto?')">
                                <i class="fas fa-<?php echo e($dulceria->activo ? 'pause' : 'play'); ?> me-2"></i>
                                <?php echo e($dulceria->activo ? 'Desactivar' : 'Activar'); ?>

                            </button>
                        </form>
                    </div>
                    
                    <div class="col-md-4">
                        <a href="<?php echo e(route('admin.dulceria.create')); ?>" class="btn btn-outline-primary w-100">
                            <i class="fas fa-plus me-2"></i>Crear Nuevo
                        </a>
                    </div>
                    
                    <div class="col-md-4">
                        <form method="POST" action="<?php echo e(route('admin.dulceria.destroy', $dulceria)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-outline-danger w-100"
                                    onclick="return confirm('¿Estás seguro de eliminar este producto? Esta acción no se puede deshacer.')">
                                <i class="fas fa-trash me-2"></i>Eliminar
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Preview de nueva imagen
    $('#imagen-input').change(function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#preview-img').attr('src', e.target.result);
                $('#imagen-preview').show();
            };
            reader.readAsDataURL(file);
        } else {
            $('#imagen-preview').hide();
        }
    });

    // Validación del formulario
    $('form[action*="update"]').submit(function(e) {
        let isValid = true;
        
        // Validar nombre
        if (!$('input[name="nombre"]').val().trim()) {
            isValid = false;
            alert('El nombre del producto es requerido');
            return false;
        }
        
        // Validar categoría
        if (!$('select[name="categoria_dulceria_id"]').val()) {
            isValid = false;
            alert('Debe seleccionar una categoría');
            return false;
        }
        
        // Validar precio
        const precio = parseFloat($('input[name="precio"]').val());
        if (!precio || precio <= 0) {
            isValid = false;
            alert('El precio debe ser mayor a 0');
            return false;
        }
        
        return isValid;
    });

    // Confirmaciones para acciones peligrosas
    $('form[action*="destroy"]').submit(function(e) {
        return confirm('¿Estás seguro de eliminar este producto? Esta acción no se puede deshacer.\n\nTodos los pedidos relacionados mantendrán la información del producto.');
    });

    $('form[action*="toggle-status"]').submit(function(e) {
        const action = $(this).find('button').text().trim();
        return confirm(`¿Estás seguro de ${action.toLowerCase()} este producto?`);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TECSUP\BDA\PROYECTO\cinema\cinema\resources\views/admin/dulceria/edit.blade.php ENDPATH**/ ?>